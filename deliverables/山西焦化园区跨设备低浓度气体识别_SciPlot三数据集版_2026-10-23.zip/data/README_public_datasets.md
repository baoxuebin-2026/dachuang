# 论文使用的三套公开数据

论文使用 UCI 361、UCI 270 和 UCI 487。原始压缩包合计约 380 MB，不纳入 Git 历史，避免普通克隆自动下载大文件。文件名、官方下载地址、字节数、DOI 和 SHA-256 记录在 `public_datasets_manifest.json`。

下载并校验：

```bash
python scripts/download_paper_datasets.py
```

文件默认保存到 `data/raw/`，该目录已被 `.gitignore` 排除。推送 `paper-datasets-v*` 标签时，GitHub Actions 会从UCI官方下载、校验并把三套原始包发布为仓库Release附件。无论从UCI还是Release下载，都应以清单中的SHA-256为准。实验代码、冻结协议、派生特征、逐块结果和论文图表保存在Git仓库中。
